from metadata import Metadata, metadata, savers
import argparse
import sys
from pprint import pprint

import os
import datetime
import hashlib
def hashFile(fname, algorithm):
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            algorithm.update(chunk)
    return algorithm.hexdigest()

def metadataGenerateFileinfo(m, args):
    filename = m.filename
    s = os.stat(filename)
    m.setMeta("file.size", s.st_size)
    m.setMeta("file.access_time", datetime.datetime.fromtimestamp(s.st_atime))
    m.setMeta("file.modification_time", datetime.datetime.fromtimestamp(s.st_mtime))
    m.setMeta("file.creation_time", datetime.datetime.fromtimestamp(s.st_ctime))
    m.setMeta("file.absolute_name", os.path.abspath(filename))
    m.setMeta("file.base_name", os.path.basename(filename))
    m.setMeta("file.prefix", os.path.splitext(filename)[0])
    m.setMeta("file.extension", os.path.splitext(filename)[1])

def metadataGenerateHash(m, args):
    filename = m.filename
    if not args.nomd5:
        m.setMeta("hash.md5", hashFile(filename, hashlib.md5()))
    if args.sha1 or args.all:
        m.setMeta("hash.sha1", hashFile(filename, hashlib.sha1()))
    if args.sha224 or args.all:
        m.setMeta("hash.sha224", hashFile(filename, hashlib.sha224()))
    if args.sha256 or args.all:
        m.setMeta("hash.sha256", hashFile(filename, hashlib.sha256()))
    if args.sha384 or args.all:
        m.setMeta("hash.sha384", hashFile(filename, hashlib.sha384()))
    if args.sha512 or args.all:
        m.setMeta("hash.sha512", hashFile(filename, hashlib.sha512()))

import filetype
def metadataGenerateFiletype2(m, args):
    filename = m.filename
    kind = filetype.guess(filename)
    if kind is None:
        print('Cannot guess file type!')
        return

    m.setMeta("filetype.extension",  kind.extension)
    m.setMeta("filetype.mime",  kind.mime)

import magic
def metadataGenerateFiletype(m, args):
    filename = m.filename
    m.setMeta("filetype.magic", magic.from_file(filename))
    f = magic.Magic(mime=True, uncompress=False)
    m.setMeta("filetype.magicMime", f.from_file(filename))
    f = magic.Magic(mime=False, uncompress=True)
    m.setMeta("filetype.magicUncompress", f.from_file(filename))
    f = magic.Magic(mime=True, uncompress=True)
    m.setMeta("filetype.magicUncompressMime", f.from_file(filename))

def metadataGenerate(args):
    for filename in args.files:
        m = metadata(filename)
        args.funcGenerate(m, args)
        m.save()

def metadataSet(args):
    for filename in args.files:
        m = metadata(filename)
        m.setMeta(args.name, args.value)
        m.save()

def metadataGet(args):
    for filename in args.files:
        m = metadata(filename)
        value = m.getMeta(args.name)
        if len(args.files) == 1:
            print str(value)
        else:
            print filename + ": " + str(value)

def metadataRemove(args):
    for filename in args.files:
        m = metadata(filename)
        m.remove(args.name)
        m.save()

def metadataSettag(args):
    for filename in args.files:
        m = metadata(filename)
        for tag in args.tags.split(","):
            m.setTag(args.taggroup, tag)
        m.save()

def metadataUnsettag(args):
    for filename in args.files:
        m = metadata(filename)
        for tag in args.tags.split(","):
            m.unsetTag(args.taggroup, tag)
        m.save()

def metadataClear(args):
    for filename in args.files:
        m = metadata(filename)
        m.clear()
        m.save()

def metadataList(args):
    for filename in args.files:
        m = metadata(filename)
        print filename + ": "
        pprint(m.list())

def metadataSavers(args):
    s = savers()
    pprint(s)


parser = argparse.ArgumentParser(description='command line metadata editor')
subparsers = parser.add_subparsers(
#                title='title set',
#                description='description set'
                )
# - add parameters
parser_set = subparsers.add_parser('set', help='sets a ame/value metadata')
parser_set.add_argument('name', type=str, help='name of the metadata')
parser_set.add_argument('value', type=str, help='value of the metadata')
parser_set.add_argument('files', nargs='+', help='files to process')
parser_set.set_defaults(func=metadataSet)

parser_get = subparsers.add_parser('get', help='gets a metadata')
parser_get.add_argument('name', type=str, help='name of the metadata')
parser_get.add_argument('files', nargs='+', help='files to process')
parser_get.set_defaults(func=metadataGet)

parser_remove = subparsers.add_parser('remove', help='removes a metadata/taggroup')
parser_remove.add_argument('name', type=str, help='name of the metadata/taggroup')
parser_remove.add_argument('files', nargs='+', help='files to process')
parser_remove.set_defaults(func=metadataRemove)

parser_unsettag = subparsers.add_parser('unsettag', help='unsets a tag')
parser_unsettag.add_argument('taggroup', type=str, help='name of the taggroup')
parser_unsettag.add_argument('tags', type=str, help='comma separated list tags to unset')
parser_unsettag.add_argument('files', nargs='+', help='files to process')
parser_unsettag.set_defaults(func=metadataUnsettag)

parser_settag = subparsers.add_parser('settag', help='set a tag')
parser_settag.add_argument('taggroup', type=str, help='name of the taggroup')
parser_settag.add_argument('tags', type=str, help='comma separated list tags to set')
parser_settag.add_argument('files', nargs='+', help='files to process')
parser_settag.set_defaults(func=metadataSettag)

parser_clear = subparsers.add_parser('clear', help='remove all metadata info')
parser_clear.add_argument('files', nargs='+', help='files to process')
parser_clear.set_defaults(func=metadataClear)

parser_list = subparsers.add_parser('list', help='list all metadata')
parser_list.add_argument('files', nargs='+', help='files to process')
parser_list.set_defaults(func=metadataList)

parser_savers = subparsers.add_parser('savers', help='list all configured savers')
parser_savers.set_defaults(func=metadataSavers)

parser_generate = subparsers.add_parser('generate', help='generate metadata info based on file/content')
subparser_generate = parser_generate.add_subparsers()
parser_generate.add_argument('files', nargs='+', help='files to process')
parser_generate.set_defaults(func=metadataGenerate)

parser_generate_fileinfo = subparser_generate.add_parser('fileinfo', help='generate file info')
parser_generate_fileinfo.set_defaults(funcGenerate=metadataGenerateFileinfo)

parser_generate_hash = subparser_generate.add_parser('hash', help='generate hash')
parser_generate_hash.add_argument('--nomd5', action='store_true', help='md5 is the default argument')
parser_generate_hash.add_argument('--sha1', action='store_true')
parser_generate_hash.add_argument('--sha224', action='store_true')
parser_generate_hash.add_argument('--sha256', action='store_true')
parser_generate_hash.add_argument('--sha384', action='store_true')
parser_generate_hash.add_argument('--sha512', action='store_true')
parser_generate_hash.add_argument('--all', action='store_true')
parser_generate_hash.set_defaults(funcGenerate=metadataGenerateHash)

parser_generate_fileinfo = subparser_generate.add_parser('filetype', help='generate type/mime info')
parser_generate_fileinfo.set_defaults(funcGenerate=metadataGenerateFiletype)

args = parser.parse_args()

args.func(args)

